import { StarshipRepository } from '../domain/ports/StarshipRepository';
import StarshipCommand from './commands/Starship.command';
export declare class StarshipCreate {
    private repository;
    constructor(repository: StarshipRepository);
    run(command: StarshipCommand): Promise<void>;
}
