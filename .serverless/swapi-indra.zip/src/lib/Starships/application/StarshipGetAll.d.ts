import { Starship } from '../domain/Starship';
import { StarshipRepository } from '../domain/ports/StarshipRepository';
export declare class StarshipGetAll {
    private repository;
    constructor(repository: StarshipRepository);
    run(): Promise<Starship[]>;
}
