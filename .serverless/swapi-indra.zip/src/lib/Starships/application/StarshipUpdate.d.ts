import { StarshipRepository } from '../domain/ports/StarshipRepository';
import { Starship } from '../domain/Starship';
import StarshipCommand from './commands/Starship.command';
export declare class StarshipUpdate {
    private repository;
    constructor(repository: StarshipRepository);
    run(name: string, command: StarshipCommand): Promise<Starship>;
}
