import { StarshipRepository } from '../domain/ports/StarshipRepository';
import { Starship } from '../domain/Starship';
export declare class StarshipGetByName {
    private repository;
    constructor(repository: StarshipRepository);
    run(name: string): Promise<Starship>;
}
