export declare class Starship {
    private name;
    private readonly model;
    private readonly manufacturer;
    private readonly starship_class;
    private readonly cost_in_credits;
    private readonly passengers;
    private readonly cargo_capacity;
    private created;
    constructor(name: string, model: string, manufacturer: string, starship_class: string, cost_in_credits: number, passengers: number, cargo_capacity: number);
    fullStarshipName(): string;
    toPlainObject(): {
        name: string;
        model: string;
        manufacturer: string;
        starship_class: string;
        cargo_capacity: number;
        passengers: number;
        created: Date;
    };
}
