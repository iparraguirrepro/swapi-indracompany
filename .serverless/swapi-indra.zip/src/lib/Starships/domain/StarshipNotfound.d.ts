export declare class StarshipNotfound extends Error {
}
