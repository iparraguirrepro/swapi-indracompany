import { Create, FindOneParams, Update } from './Validations';
import { StarshipCreate } from '../application/StarshipCreate';
import { StarshipGetAll } from '../application/StarshipGetAll';
import { StarshipGetByName } from '../application/StarshipGetByName';
import { StarshipUpdate } from '../application/StarshipUpdate';
export declare class StarshipController {
    private readonly starshipGetAll;
    private readonly starshipGetByName;
    private readonly starshipCreate;
    private readonly starshipUpdate;
    constructor(starshipGetAll: StarshipGetAll, starshipGetByName: StarshipGetByName, starshipCreate: StarshipCreate, starshipUpdate: StarshipUpdate);
    getAll(): Promise<{
        name: string;
        model: string;
        manufacturer: string;
        starship_class: string;
        cargo_capacity: number;
        passengers: number;
        created: Date;
    }[]>;
    getByBName(params: FindOneParams): Promise<{
        name: string;
        model: string;
        manufacturer: string;
        starship_class: string;
        cargo_capacity: number;
        passengers: number;
        created: Date;
    }>;
    create(body: Create): Promise<void>;
    updateByName(params: FindOneParams, body: Update): Promise<import("../domain/Starship").Starship>;
}
