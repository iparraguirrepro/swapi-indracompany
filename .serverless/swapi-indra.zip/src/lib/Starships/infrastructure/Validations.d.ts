export declare class FindOneParams {
    name: string;
}
export declare class Create {
    name: string;
    model: string;
    manufacturer: string;
    starship_class: string;
    cost_in_credits: number;
    passengers: number;
    cargo_capacity: number;
}
export declare class Update {
    name: string;
    model: string;
    manufacturer: string;
    starship_class: string;
    cost_in_credits: number;
    passengers: number;
    cargo_capacity: number;
}
