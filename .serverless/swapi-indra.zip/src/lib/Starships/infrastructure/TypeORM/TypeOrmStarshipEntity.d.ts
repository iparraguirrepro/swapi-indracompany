export declare class TypeOrmStarshipEntity {
    name: string;
    model: string;
    manufacturer: string;
    starship_class: string;
    cost_in_credits: number;
    passengers: number;
    cargo_capacity: number;
    request_at: Date;
}
