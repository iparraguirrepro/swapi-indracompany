import { Repository } from 'typeorm';
import { TypeOrmStarshipEntity } from './TypeOrmStarshipEntity';
import { StarshipRepository } from '../../domain/ports/StarshipRepository';
import { Starship } from '../../domain/Starship';
export declare class TypeOrmStarshipRepository implements StarshipRepository {
    private readonly repository;
    constructor(repository: Repository<TypeOrmStarshipEntity>);
    private mapToDomain;
    getAll(): Promise<Starship[]>;
    create(user: Starship): Promise<void>;
    getByBName(name: string): Promise<Starship>;
    updateByName(starship_name: string, starship: any): Promise<Starship>;
}
