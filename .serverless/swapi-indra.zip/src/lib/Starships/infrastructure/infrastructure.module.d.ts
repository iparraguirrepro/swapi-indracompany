export declare class StarshipModule {
}
